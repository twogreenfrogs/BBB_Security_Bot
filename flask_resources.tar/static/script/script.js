﻿var btn_wifi = document.getElementById("button_wifi");
btn_wifi.addEventListener("click", function () { 
	button_wifi.src = "{{ url_for('static', filename='images/off_button.jpeg')}}"; 
} );
